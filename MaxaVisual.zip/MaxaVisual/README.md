# MaxaVisual (Minecraft 1.21.4 / Fabric)

A starter client-side Fabric mod with a dark, two-column click GUI and Visuals / HUD / Utilities categories.

## Important status
This is an early GUI prototype. The module names currently toggle UI state only; most named gameplay/render features are not implemented yet. It has not been built or tested in Minecraft in this environment.

## Build on a computer
Requires Java 21 and Gradle. Run `gradle build`; output is in `build/libs/`.

## Build using only a phone browser (GitHub Actions)
1. Sign in to GitHub in your phone browser and create a new repository.
2. Upload the contents of this project ZIP to the repository (make sure `.github/workflows/build.yml` is included).
3. Open the repository's **Actions** tab and select **Build MaxaVisual**.
4. If it has not run automatically, tap **Run workflow**.
5. When it finishes successfully, open that run and download the **MaxaVisual-1.21.4** artifact. It downloads as a ZIP; extract it on your phone and copy the `.jar` into PojavLauncher's `mods` folder.

Use Fabric for Minecraft 1.21.4 with Java 21. This prototype may still need fixes after its first cloud build; share any build error here.
