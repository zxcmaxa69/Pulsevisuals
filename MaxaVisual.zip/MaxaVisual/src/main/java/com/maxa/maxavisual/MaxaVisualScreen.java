package com.maxa.maxavisual;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.*;

public class MaxaVisualScreen extends Screen {
    private enum Category { VISUALS, HUD, UTILITIES }
    private Category category = Category.VISUALS;
    private int accent = 0xFF8B5CF6;
    private int scroll = 0;
    private final Map<String, Boolean> enabled = new LinkedHashMap<>();
    private final List<String> visuals = List.of(
        "Animations", "Arrow Nametag", "Aspect Ratio", "Atmosphere", "Block Overlay", "Body Glow", "China Hat", "Crosshair", "Custom Hand", "Custom Sound", "Full Bright", "Hit Bubbles", "Hit Color", "Hit Range", "Hitbox Customize", "Item Physic", "Jump Circles", "Kill Effects", "Motion Blur", "Nimb", "Particles", "Render Tweaks", "Self Nametag", "Tab Customizer", "Target ESP", "Trails", "World Customizer", "World Particles"
    );
    private final List<String> hud = List.of(
        "Armor HUD", "Cooldowns HUD", "Effect Notify", "Hit Counter", "Hot Keys", "Inventory HUD", "Potions", "Saturation HUD", "Target HUD", "Totem Bar", "Watermark"
    );
    private final List<String> utilities = List.of(
        "Auto Command", "Chat Helper", "Cooldowns", "Fakeplayer", "Fast Swap", "Free Look", "FT Regions", "Healing Helper", "Item Highlighter", "Lock Slot", "Mace Helper", "Optimization", "PVP Safe", "Sound Controller", "Zoom"
    );

    public MaxaVisualScreen() { super(Text.literal("MaxaVisual")); }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0xB8000000);
        int panelW = Math.min(520, width - 20);
        int panelH = Math.min(330, height - 20);
        int x = (width - panelW) / 2, y = (height - panelH) / 2;
        ctx.fill(x, y, x + panelW, y + panelH, 0xFF101014);
        ctx.fill(x, y, x + 4, y + panelH, accent);
        ctx.fill(x + 4, y, x + panelW, y + 35, 0xFF18181F);
        ctx.drawText(textRenderer, "✦ MaxaVisual", x + 15, y + 12, 0xFFFFFFFF, false);
        ctx.drawText(textRenderer, "THEME", x + panelW - 86, y + 12, 0xFFB9B9C7, false);
        int[] colors = {0xFF8B5CF6, 0xFF36C5F0, 0xFF47D18C, 0xFFFFB84D, 0xFFFF5C7A, 0xFFFFFFFF};
        for (int i = 0; i < colors.length; i++) {
            int cx = x + panelW - 84 + (i % colors.length) * 12;
            ctx.fill(cx, y + 22, cx + 8, y + 30, colors[i]);
        }
        // Sidebar/category icons
        int sideX = x + 12, sideY = y + 48;
        drawCategory(ctx, sideX, sideY, "◈", "Visuals", Category.VISUALS, mouseX, mouseY);
        drawCategory(ctx, sideX, sideY + 42, "▦", "HUD", Category.HUD, mouseX, mouseY);
        drawCategory(ctx, sideX, sideY + 84, "⚙", "Utilities", Category.UTILITIES, mouseX, mouseY);
        ctx.drawText(textRenderer, "Tap a module to toggle", x + 118, y + 47, 0xFF9A9AA8, false);
        List<String> items = currentItems();
        int contentX = x + 116, contentY = y + 66;
        int gap = 8;
        int colW = (panelW - 134) / 2;
        int rowH = 27;
        int visibleRows = Math.max(1, (panelH - 91) / (rowH + gap));
        int start = Math.min(scroll, Math.max(0, (items.size() + 1) / 2 - visibleRows));
        for (int i = 0; i < items.size(); i++) {
            int row = i / 2, col = i % 2;
            if (row < start || row >= start + visibleRows) continue;
            int bx = contentX + col * (colW + gap), by = contentY + (row - start) * (rowH + gap);
            boolean on = enabled.getOrDefault(items.get(i), false);
            boolean hover = mouseX >= bx && mouseX <= bx + colW && mouseY >= by && mouseY <= by + rowH;
            ctx.fill(bx, by, bx + colW, by + rowH, on ? accent : (hover ? 0xFF30303B : 0xFF22222A));
            ctx.drawText(textRenderer, items.get(i), bx + 8, by + 9, 0xFFFFFFFF, false);
            ctx.drawText(textRenderer, on ? "ON" : "OFF", bx + colW - 28, by + 9, on ? 0xFFFFFFFF : 0xFF9292A0, false);
        }
        ctx.drawText(textRenderer, "MaxaVisual  •  1.21.4  •  Right Shift: close", x + 14, y + panelH - 17, 0xFF777784, false);
        super.render(ctx, mouseX, mouseY, delta);
    }

    private void drawCategory(DrawContext ctx, int x, int y, String icon, String label, Category c, int mx, int my) {
        boolean active = category == c;
        boolean hover = mx >= x && mx <= x + 92 && my >= y && my <= y + 32;
        ctx.fill(x, y, x + 92, y + 32, active ? accent : (hover ? 0xFF2A2A34 : 0xFF1C1C23));
        ctx.drawText(textRenderer, icon, x + 7, y + 10, 0xFFFFFFFF, false);
        ctx.drawText(textRenderer, label, x + 25, y + 10, 0xFFFFFFFF, false);
    }

    private List<String> currentItems() {
        return switch (category) { case VISUALS -> visuals; case HUD -> hud; case UTILITIES -> utilities; };
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        int panelW = Math.min(520, width - 20), panelH = Math.min(330, height - 20);
        int x = (width - panelW) / 2, y = (height - panelH) / 2;
        int sideX = x + 12, sideY = y + 48;
        if (inside(mouseX, mouseY, sideX, sideY, 92, 32)) { category = Category.VISUALS; scroll = 0; return true; }
        if (inside(mouseX, mouseY, sideX, sideY + 42, 92, 32)) { category = Category.HUD; scroll = 0; return true; }
        if (inside(mouseX, mouseY, sideX, sideY + 84, 92, 32)) { category = Category.UTILITIES; scroll = 0; return true; }
        int[] colors = {0xFF8B5CF6, 0xFF36C5F0, 0xFF47D18C, 0xFFFFB84D, 0xFFFF5C7A, 0xFFFFFFFF};
        for (int i = 0; i < colors.length; i++) {
            int cx = x + panelW - 84 + i * 12;
            if (inside(mouseX, mouseY, cx, y + 22, 8, 8)) { accent = colors[i]; return true; }
        }
        List<String> items = currentItems();
        int contentX = x + 116, contentY = y + 66, gap = 8;
        int colW = (panelW - 134) / 2, rowH = 27;
        int visibleRows = Math.max(1, (panelH - 91) / (rowH + gap));
        int start = Math.min(scroll, Math.max(0, (items.size() + 1) / 2 - visibleRows));
        for (int i = 0; i < items.size(); i++) {
            int row = i / 2, col = i % 2;
            if (row < start || row >= start + visibleRows) continue;
            int bx = contentX + col * (colW + gap), by = contentY + (row - start) * (rowH + gap);
            if (inside(mouseX, mouseY, bx, by, colW, rowH)) {
                String name = items.get(i); enabled.put(name, !enabled.getOrDefault(name, false)); return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int rows = (currentItems().size() + 1) / 2;
        int visible = Math.max(1, (Math.min(330, height - 20) - 91) / 35);
        scroll = Math.max(0, Math.min(Math.max(0, rows - visible), scroll + (verticalAmount < 0 ? 1 : -1)));
        return true;
    }

    @Override public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT || keyCode == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private boolean inside(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx <= x + w && my >= y && my <= y + h; }
}
